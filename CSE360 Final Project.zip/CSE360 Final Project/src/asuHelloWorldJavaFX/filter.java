/* Name: Sarthak Aggarwal
 * ASU ID: 1222329095
 * Effortlogger V2 Risk Reduction Prototype
 * */

package asuHelloWorldJavaFX;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;
 
public class ASUHelloWorldJavaFX extends Application {
	private boolean running = false;
    private int seconds = 0;
    private int minutes = 0;
    private int hours = 0;
    private int submitCount = 0;
    private Timeline timeline;
    private boolean terminate=false;
    public static void main(String[] args) {
        launch(args);
    }
    private List<Map<String, String>> historyData = Arrays.asList(
            Map.of("Project", "Business", "Life cycle step", "Information Gathering", "Effort Category", "Deliverables", "Deliverable", "Conceptual Design", "Score", "4"),
            Map.of("Project", "Business", "Life cycle step", "Verifying", "Effort Category", "Interruptions", "Deliverable", "Break", "Score", "3"),
            Map.of("Project", "Development", "Life cycle step", "Requirements", "Effort Category", "Defects", "Deliverable", "NONE", "Score", "3"),
            Map.of("Project", "Development", "Life cycle step", "Reflection", "Effort Category", "Plans", "Deliverable", "Project Plan", "Score", "2"),
            Map.of("Project", "Business", "Life cycle step", "Outlining", "Effort Category", "Plans", "Deliverable", "Project Plan", "Score", "1"),
            Map.of("Project", "Business", "Life cycle step", "Drafting", "Effort Category", "Interruptions", "Deliverable", "Phone", "Score", "4"),
            Map.of("Project", "Development", "Life cycle step", "Problem Understanding", "Effort Category", "Deliverables", "Deliverable", "Test Cases", "Score", "2"),
            Map.of("Project", "Development", "Life cycle step", "Solution Review", "Effort Category", "Deliverables", "Deliverable", "Report", "Score", "3")
    );

    @Override
    
    public void start(Stage primaryStage) {
    	

    	// Set up the main layout
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);

        // Create and format the title label
        Label titleLabel = new Label("Effort Logger History Filter");
        titleLabel.setFont(Font.font("Arial", 16));
        titleLabel.setStyle("-fx-font-weight: bold;");

        // Create the Project label and dropdown menu
        Label projectLabel = new Label("Project:");
        ComboBox<String> projectComboBox = new ComboBox<>();
        projectComboBox.getItems().addAll("Development", "Business","");
        projectComboBox.setValue(""); // Default selection

        // Create the feature label and dropdown menu
        Label featureLabel = new Label("Weight");
        ComboBox<Integer> weightComboBox = new ComboBox<>();
        weightComboBox.getItems().addAll(0, 1, 2, 3, 4);
        weightComboBox.setValue(0); // Default selection
        
     // Create the Lifecycle Step label and dropdown menu
        Label lifecycleStepLabel = new Label("Lifecycle Step:");
        ComboBox<String> lifecycleStepComboBox = new ComboBox<>();
        lifecycleStepComboBox.getItems().addAll(
            "Planning", "Information Gathering", "Information Understanding",
            "Verifying", "Outlining", "Drafting", "Finalising",
            "Team meeting", "Coach meeting", "Stakeholder meeting"
        );
        lifecycleStepComboBox.setValue(""); // Default selection is empty

        // Create the Submit button
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(event -> {
            int selectedScore = weightComboBox.getValue();
            String selectedProject = projectComboBox.getValue();
            String selectedLifecycleStep = lifecycleStepComboBox.getValue();
            displayRecordWithFilters(selectedScore, selectedProject, selectedLifecycleStep, root);
        });

        // Create a TextArea to display the selected record
        TextArea displayArea = new TextArea();
        displayArea.setEditable(false);
        
        // Add the components to the layout
        root.getChildren().addAll(titleLabel, projectLabel, projectComboBox,lifecycleStepLabel, lifecycleStepComboBox, featureLabel, weightComboBox, submitButton, displayArea);

        // Set up the scene and stage
        Scene scene = new Scene(root, 800, 600);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        primaryStage.setTitle("Effort Logger History Filter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void displayRecordWithFilters(int selectedScore, String selectedProject, String selectedLifecycleStep, VBox root) {
        List<Map<String, String>> matchingRecords = historyData.stream()
                .filter(record -> selectedScore == Integer.parseInt(record.get("Score")) || selectedScore == 0)
                .filter(record -> selectedProject.isEmpty() || selectedProject.equals(record.get("Project")))
                .filter(record -> selectedLifecycleStep.isEmpty() || selectedLifecycleStep.equals(record.get("Life cycle step")))
                .collect(Collectors.toList());

        // Display matching records in the TextArea
        if (!matchingRecords.isEmpty()) {
            StringBuilder displayText = new StringBuilder("Matching Records:\n");

            for (Map<String, String> record : matchingRecords) {
                displayText.append("Project: ").append(record.get("Project")).append("\n");
                displayText.append("Life cycle step: ").append(record.get("Life cycle step")).append("\n");
                displayText.append("Effort Category: ").append(record.get("Effort Category")).append("\n");
                displayText.append("Deliverable: ").append(record.get("Deliverable")).append("\n");
                displayText.append("Score: ").append(record.get("Score")).append("\n");
                displayText.append("\n-------------------\n");
            }

            TextArea displayArea = (TextArea) root.getChildren().get(root.getChildren().size() - 1);
            displayArea.setText(displayText.toString());
        } else {
            TextArea displayArea = (TextArea) root.getChildren().get(root.getChildren().size() - 1);
            displayArea.setText("No matching records found.");
        }
    }
   }