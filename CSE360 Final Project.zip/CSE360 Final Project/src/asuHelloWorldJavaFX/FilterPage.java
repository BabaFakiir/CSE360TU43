/* Name: Sarthak Aggarwal
 * ASU ID: 1222329095
 * Effortlogger V2 Risk Reduction Prototype
 * */

package asuHelloWorldJavaFX;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;
 
public class FilterPage extends Application {
	private boolean running = false;
    private int seconds = 0;
    private int minutes = 0;
    private int hours = 0;
    private int submitCount = 0;
    private Timeline timeline;
    private boolean terminate=false;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    
    public void start(Stage primaryStage) {
    	// Create a dropdown menu
    	Label label1 = new Label("1. Select the project");
        ComboBox<String> dropdown = new ComboBox<>();
        dropdown.getItems().addAll("Business Project", "Development Project");

        // Create a button
        Label label2 = new Label("2. Clear the Project Defect Log");
        Button button = new Button("Clear this Defect Log");
        button.setOnAction(e -> {
            String selectedOption = dropdown.getValue();
            if (selectedOption != null) {
                System.out.println("Selected Option: " + selectedOption);
            } else {
                System.out.println("No option selected.");
            }
        });
        Label label3 = new Label("Select one of the following defects to make it the current one or select 'Create a New Defect'");
        ComboBox<String> dropdown1 = new ComboBox<>();
        dropdown1.getItems().addAll("-no defect selected-");
        dropdown1.setPromptText("-no defect selected-");
        Button button1 = new Button("Create a New Defect");
        
        Label label4 = new Label("Define or update the following Current Defect Attributes:");
        Label label5 = new Label("Defect Name");
        TextField nameTextField = new TextField();
        
        Label label6 = new Label("Defect Symptoms or Cause/Resolution");
        TextField symptoms = new TextField();
        
        Label label7 = new Label("Step when injected");
        ComboBox<String> dropdown2 = new ComboBox<>();
        dropdown2.getItems().addAll("Option 1", "Option 2","Option 3");
        
        Label label8 = new Label("Step when removed");
        ComboBox<String> dropdown3 = new ComboBox<>();
        dropdown3.getItems().addAll("Option 1", "Option 2","Option 3");
        
        Label label9 = new Label("Step when removed");
        ComboBox<String> dropdown4 = new ComboBox<>();
        dropdown4.getItems().addAll("Option 1", "Option 2","Option 3");
        
        Label label10 = new Label("Fix:");
        TextField fix = new TextField();
        
        Label label11 = new Label("Press the (Update the Current Defect) to save the changes made above.");
        Button button2 = new Button("Update the Current Defect");
        Button button3 = new Button("Delete the Current Defect");
        Button button4 = new Button("Proceed to the Effort Log");
        // Create a layout and add the button and dropdown menu to it
        VBox root = new VBox(10);
        root.getChildren().addAll(label1,dropdown,label2, button, label3, dropdown1,button1,label4,label5,nameTextField,label6,symptoms,label7,dropdown2,label8,dropdown3,label9,dropdown4,label10,fix,label11,button2,button3,button4);

        // Create a scene and set it on the stage
        Scene scene = new Scene(root, 300, 200);
        primaryStage.setTitle("JavaFX Dropdown Menu Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
   }